<div>
    <h1>Logout</h1>
    <p>You have successfully logged out.</p>
    <a href="login.php">Login again</a>
</div>