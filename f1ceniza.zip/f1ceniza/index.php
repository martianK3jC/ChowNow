<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChowNow - Restaurant System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <?php include 'includes/header.php'; ?>
    
    <!-- MAIN CONTENT -->
    <main>
        <h2>Welcome to ChowNow</h2>
        <p>Efficient, Fast, and Reliable Order Management System for Restaurants.</p>

        <!-- Button to link to dashboard -->
        <button>
            <a href="dashboard.php" style="text-decoration: none; color: black;">Go to Dashboard</a>
        </button>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="script.js"></script>
</body>
</html>