<?php
include 'connect.php';

// Check if ID is provided
if (!isset($_GET['id'])) {
    echo "<script>alert('No student selected!'); window.location='dashboard.php';</script>";
    exit();
}

$uid = $_GET['id'];

// Fetch user data
$query = "SELECT * FROM tbluser INNER JOIN tblstudent ON tbluser.uid = tblstudent.uid WHERE tbluser.uid = $uid";
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 0) {
    echo "<script>alert('Student not found!'); window.location='dashboard.php';</script>";
    exit();
}

$row = mysqli_fetch_assoc($result);

// Update student record
if (isset($_POST['btnUpdate'])) {
    $fname = $_POST['txtfirstname'];
    $lname = $_POST['txtlastname'];
    $gender = $_POST['txtgender'];
    $utype = $_POST['txtusertype'];
    $uname = $_POST['txtusername'];
    $prog = $_POST['txtprogram'];
    $yearlevel = $_POST['txtyearlevel'];

    // Update tbluser
    $updateUser = "UPDATE tbluser SET firstname='$fname', lastname='$lname', gender='$gender', usertype='$utype', username='$uname' WHERE uid=$uid";
    mysqli_query($connection, $updateUser);

    // Update tblstudent
    $updateStudent = "UPDATE tblstudent SET program='$prog', yearlevel='$yearlevel' WHERE uid=$uid";
    mysqli_query($connection, $updateStudent);

    echo "<script>alert('Student updated successfully!'); window.location='dashboard.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Update Student</h2>
    <form method="post">
        Firstname: <input type="text" name="txtfirstname" value="<?php echo $row['firstname']; ?>" required><br>
        Lastname: <input type="text" name="txtlastname" value="<?php echo $row['lastname']; ?>" required><br>
        Gender:
        <select name="txtgender" required>
            <option value="Male" <?php if ($row['gender'] == 'Male') echo 'selected'; ?>>Male</option>
            <option value="Female" <?php if ($row['gender'] == 'Female') echo 'selected'; ?>>Female</option>
        </select><br>
        User Type:
        <select name="txtusertype" required>
            <option value="student" <?php if ($row['usertype'] == 'student') echo 'selected'; ?>>Student</option>
            <option value="employee" <?php if ($row['usertype'] == 'employee') echo 'selected'; ?>>Employee</option>
        </select><br>
        Username: <input type="text" name="txtusername" value="<?php echo $row['username']; ?>" required><br>
        Program:
        <select name="txtprogram" required>
            <option value="bsit" <?php if ($row['program'] == 'bsit') echo 'selected'; ?>>BSIT</option>
            <option value="bscs" <?php if ($row['program'] == 'bscs') echo 'selected'; ?>>BSCS</option>
        </select><br>
        Year Level:
        <select name="txtyearlevel" required>
            <option value="1" <?php if ($row['yearlevel'] == 1) echo 'selected'; ?>>1</option>
            <option value="2" <?php if ($row['yearlevel'] == 2) echo 'selected'; ?>>2</option>
            <option value="3" <?php if ($row['yearlevel'] == 3) echo 'selected'; ?>>3</option>
            <option value="4" <?php if ($row['yearlevel'] == 4) echo 'selected'; ?>>4</option>
        </select><br>
        <input type="submit" name="btnUpdate" value="Update Student">
    </form>

    
    <div>
        <button><a href="dashboard.php">Go back to dashboard</a></button>
    </div> 
</body>
</html>
