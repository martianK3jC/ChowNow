<!--connect.php-->
<?php 
	$connection = new mysqli('localhost', 'root','','dbf1ceniza');
	
	if (!$connection){
		die (mysqli_error($mysqli));
	}
?>