<?php include 'connect.php'; ?>

<h2>Add New Student</h2>
<form method="post">
    Firstname: <input type="text" name="txtfirstname" required><br>
    Lastname: <input type="text" name="txtlastname" required><br>
    Gender:
    <select name="txtgender" required>
        <option value="">----</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </select><br>
    User Type:
    <select name="txtusertype" required>
        <option value="">----</option>
        <option value="student">Student</option>
        <option value="employee">Employee</option>
    </select><br>
    Username: <input type="text" name="txtusername" required><br>
    Password: <input type="password" name="txtpassword" required><br>
    Program:
    <select name="txtprogram" required>
        <option value="">----</option>
        <option value="bsit">BSIT</option>
        <option value="bscs">BSCS</option>
    </select><br>
    Year Level:
    <select name="txtyearlevel" required>
        <option value="">----</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
    </select><br>
    <input type="submit" name="btnAddStudent" value="Add Student">
</form>


<?php
if(isset($_POST['btnAddStudent'])){
    $fname = $_POST['txtfirstname'];
    $lname = $_POST['txtlastname'];
    $gender = $_POST['txtgender'];
    $utype = $_POST['txtusertype'];
    $uname = $_POST['txtusername'];
    $pword = $_POST['txtpassword'];
    $hashedpw = password_hash($pword, PASSWORD_DEFAULT);
    $prog = $_POST['txtprogram'];
    $yearlevel = $_POST['txtyearlevel'];

    // Insert into tbluser first
    $sql1 = "INSERT INTO tbluser(firstname, lastname, gender, usertype, username, password) 
            VALUES('$fname', '$lname', '$gender', '$utype', '$uname', '$hashedpw')";
    if(mysqli_query($connection, $sql1)){
        $last_id = mysqli_insert_id($connection);
        $sql2 = "INSERT INTO tblstudent(program, yearlevel, uid) 
                VALUES('$prog', '$yearlevel', '$last_id')";
        mysqli_query($connection, $sql2);
        echo "<script>alert('New student added successfully.'); window.location='dashboard.php';</script>";
    } else {
        echo "<script>alert('Error adding student.');</script>";
    }
}
?>

<div>
        <button><a href="dashboard.php">Go back to dashboard</a></button>
    </div> 
