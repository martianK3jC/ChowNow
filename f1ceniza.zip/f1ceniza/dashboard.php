<!-- filepath: c:\xampp\htdocs\f1ceniza\register.php -->
<?php    
    include 'connect.php';    
    require_once 'includes/header.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>
    <div style="background-color: #ffff00; padding: 10px;">
        <center>
            <h2 style="color: white;">User Registration Page</h2>
        </center>
    </div>  

    <div class="registration-form" style="max-width: 600px; margin: 20px auto; padding: 20px; background: #f9f9f9; border-radius: 10px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);">
        <form method="post">
            <label for="txtfirstname">Firstname:</label>
            <input type="text" id="txtfirstname" name="txtfirstname" required><br><br>

            <label for="txtlastname">Lastname:</label>
            <input type="text" id="txtlastname" name="txtlastname" required><br><br>

            <label for="txtgender">Gender:</label>
            <select id="txtgender" name="txtgender" required>
                <option value="">----</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select><br><br>

            <label for="txtusertype">User Type:</label>
            <select id="txtusertype" name="txtusertype" required>
                <option value="">----</option>
                <option value="student">Student</option>
                <option value="employee">Employee</option>
            </select><br><br>

            <label for="txtusername">Username:</label>
            <input type="text" id="txtusername" name="txtusername" required><br><br>

            <label for="txtpassword">Password:</label>
            <input type="password" id="txtpassword" name="txtpassword" required><br><br>

            <label for="txtprogram">Program:</label>
            <select id="txtprogram" name="txtprogram" required>
                <option value="">----</option>
                <option value="bsit">BSIT</option>
                <option value="bscs">BSCS</option>
            </select><br><br>

            <label for="txtyearlevel">Year Level:</label>
            <select id="txtyearlevel" name="txtyearlevel" required>
                <option value="">----</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
            </select><br><br>

            <input type="submit" name="btnRegister" value="Register" class="btn">
        </form>
        <div style="margin-top: 20px;">
            <button class="btn"><a href="dashboard.php" style="text-decoration: none; color: white;">Go to Dashboard</a></button>
        </div>
    </div>
</body>
</html>

<?php	
    if (isset($_POST['btnRegister'])) {		
        // Retrieve data from form
        $fname = $_POST['txtfirstname'];		
        $lname = $_POST['txtlastname'];
        $gender = $_POST['txtgender'];
        $utype = $_POST['txtusertype'];
        $uname = $_POST['txtusername'];		
        $pword = $_POST['txtpassword'];	
        $hashedpw = password_hash($pword, PASSWORD_DEFAULT);
        
        $prog = $_POST['txtprogram'];		
        $yearlevel = $_POST['txtyearlevel'];		
        
        // Save data to tbluser	
        $sql1 = "INSERT INTO tbluser (firstname, lastname, gender, usertype, username, password) 
                 VALUES ('$fname', '$lname', '$gender', '$utype', '$uname', '$hashedpw')";
        mysqli_query($connection, $sql1);
                
        $last_id = mysqli_insert_id($connection);
         
        // Save data to tblstudent
        $sql2 = "INSERT INTO tblstudent (program, yearlevel, uid) 
                 VALUES ('$prog', '$yearlevel', '$last_id')";
        mysqli_query($connection, $sql2);

        echo "<script>alert('New record saved.');</script>";
        header("location: dashboard.php");
    }
?>

<?php 
require_once 'includes/footer.php'; 
?>