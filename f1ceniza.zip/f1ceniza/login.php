<div>
    <h1>This is still in construction🚧</h1>
    <Button><a href="dashboard.php">Go to dashboard</a></Button>

    <Button><a href="register.php">Register</a></Button>
</div>