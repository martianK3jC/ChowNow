<footer>
    <p>Kesha Jane Ceniza | BSCS - 2nd Year</p>
</footer>