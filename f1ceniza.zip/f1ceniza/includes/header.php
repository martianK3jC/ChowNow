<!-- HEADER -->
<header>
<link rel="stylesheet" href="styles.css">
        <div class="header-left">
            <div class="logo">
                <img src="resources/logoChowNow.png" alt="Logo">
            </div>
            <h1>ChowNow</h1>
        </div>
        <nav>
            <ul>
                <li><a href="login.php" id="loginBtn">Login</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </nav>
    </header>